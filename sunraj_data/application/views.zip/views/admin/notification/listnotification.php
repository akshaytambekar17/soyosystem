    <div class="container top">

      <ul class="breadcrumb">
        <li>
          <a href="<?php echo site_url("admin"); ?>">
            <?php echo ucfirst($this->uri->segment(1));?>
          </a> 
          <span class="divider">/</span>
        </li>
        <li class="active">
          <?php echo ucfirst("Notifications");?>
        </li>
      </ul>

      <div class="page-header users-header">
        <h2>
          <?php echo ucfirst("Notifications");?> 
          
        </h2>
      </div>
      
      <div class="row">
        <div class="span12 columns">
          <div class="well">
           
            <?php
           
            $attributes = array('class' => 'form-inline reset-margin', 'id' => 'myform');
           
            //save the columns names in a array that we will use as filter         
            $options_manufacturers = array();    
            foreach ($manufacturers as $array) {
              foreach ($array as $key => $value) {
                $options_manufacturers[$key] = $key;
              }
              break;
            }
			
            echo form_open('admin/notification/listnotification', $attributes);
     
              echo form_label('Search:', 'search_string');
              echo form_input('search_string', $search_string_selected);

              echo form_label('Order by:', 'order');
              echo form_dropdown('order', $options_manufacturers, $order, 'class="span2"');

              $data_submit = array('name' => 'mysubmit', 'class' => 'btn btn-primary', 'value' => 'Go');

              $options_order_type = array('Asc' => 'Asc', 'Desc' => 'Desc');
              echo form_dropdown('order_type', $options_order_type, $order_type_selected, 'class="span1"');

              echo form_submit($data_submit);

            echo form_close();
            ?>
          </div>

          <table class="table table-striped table-bordered table-condensed">
            <thead>
              <tr>
                <th class="header">#</th>
                <th class="yellow header headerSortDown">Message</th>
                <th class="yellow header headerSortDown">Date</th>
                <th class="yellow header headerSortDown">Sender</th>
				 <th class="yellow header headerSortDown">Status</th>
				 <th class="yellow header headerSortDown">Type</th>
              </tr>
            </thead>
            <tbody>
              <?php
              foreach($manufacturers as $row)
              {
                echo '<tr>';
                echo '<td>'.$row['notid'].'</td>';
                echo '<td>'.$row['message'].'</td>';
                echo '<td>'.$row['datetime'].'</td>';
                echo '<td>'.$row['fullname'].'</td>';
				
				
				if($row['isread']==1)
				{
					 echo '<td class="crud-actions">  
                    <a href="'.site_url("admin").'/notification/approve/'.$row['notid'].'/approve" class="btn btn-info">Approve</a>  
                  <a href="'.site_url("admin").'/notification/updatestatus/'.$row['notid'].'/reject" class="btn btn-danger">Reject</a>
                </td>';
				}
				else
				{
					 echo '<td class="crud-actions">  
					  <a href="'.site_url("admin").'/notification/deletenotification/'.$row['notid'].'" class="btn btn-danger">Delete</a>
					</td>';
				}
					 
			
						if($row['type']==0)
				{
					 echo '<td class="btn btn-primary">Labour Confirmation</td>';
				}
				else if($row['type']==1)
				{
					 echo '<td class="btn btn-warning">shift management</td>';
				}
				else if($row['type']==2)
				{
					 echo '<td class="btn btn-success">leave confirmation</td>';
				}
				
            
                echo '</tr>';
              }
              ?>      
            </tbody>
          </table>

          <?php echo '<div class="pagination">'.$this->pagination->create_links().'</div>'; ?>

      </div>
    </div>