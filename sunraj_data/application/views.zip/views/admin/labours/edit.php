    <div class="container top">
      
      <ul class="breadcrumb">
        <li>
          <a href="<?php echo site_url("admin"); ?>">
            <?php echo ucfirst($this->uri->segment(1));?>
          </a> 
          <span class="divider">/</span>
        </li>
        <li>
          <a href="<?php echo site_url("admin").'/'.$this->uri->segment(2); ?>">
            <?php echo ucfirst($this->uri->segment(2));?>
          </a> 
          <span class="divider">/</span>
        </li>
        <li class="active">
          <a href="#">Update</a>
        </li>
      </ul>
      
      <div class="page-header">
        <h2>
          Updating <?php echo ucfirst($this->uri->segment(2));?>
        </h2>
      </div>

 
      <?php if($message = $this -> session -> flashdata('message')){?>
            <div class="col-md-12 pull-right">
                <div class="alert alert-dismissible alert-success">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <?=$message ?>
                </div>
            </div>
      <?php }?> 
      
      <?php
      //form data
      $attributes = array('class' => 'form-horizontal', 'id' => '');
      $options_manufacture = array('' => "Select");
      foreach ($manufactures as $row)
      {
        $options_manufacture[$row['userid']] = $row['fullname'];
      }
      //echo "<pre>";print_r($options_manufacture);die();
      //form validation
      echo validation_errors();

      echo form_open('admin/labours/update/'.$this->uri->segment(4).'', $attributes);
      ?>
        <fieldset>
          <div class="control-group">
            <label for="inputError" class="control-label">Full Name</label>
            <div class="controls">
              <input type="text" id="" name="fullname" value="<?php echo $product[0]['fullname']; ?>" >
              <!--<span class="help-inline">Woohoo!</span>-->
            </div>
          </div>
          <div class="control-group">
            <label for="inputError" class="control-label">Address</label>
            <div class="controls">
              <input type="text" id="" name="address" value="<?php echo $product[0]['address']; ?>">
              <!--<span class="help-inline">Cost Price</span>-->
            </div>
          </div>          
          <div class="control-group">
            <label for="inputError" class="control-label">Mobile No</label>
            <div class="controls">
              <input type="text" id="" name="mobno" value="<?php echo $product[0]['mobno'];?>">
              <!--<span class="help-inline">Cost Price</span>-->
            </div>
          </div>
          <div class="control-group">
            <label for="inputError" class="control-label">Email-id</label>
            <div class="controls">
              <input type="text" name="email" value="<?php echo $product[0]['email']; ?>">
              <!--<span class="help-inline">OOps</span>-->
            </div>
          </div>


          <?php
          echo '<div class="control-group">';
            echo '<label for="manufacture_id" class="control-label">Superviser</label>';
            echo '<div class="controls">';
              //echo form_dropdown('manufacture_id', $options_manufacture, '', 'class="span2"');
              $product_name = array($product[0]['supid']);        
              echo form_dropdown('supid',$options_manufacture,$product_name,'class="span2"');

            echo '</div>';
          echo '</div">';
          ?>
          <div class="control-group">
            <div class="controls">
              <img src="<?php echo base_url().'/'.$product[0]['pofilepath']; ?>" />
              
              <!--<span class="help-inline">OOps</span>-->
            </div>
          </div>

          <div class="form-actions">
            <button class="btn btn-primary" type="submit">Save Changes</button>
            <a href="<?=site_url("admin")?>/labours" class="btn btn-danger">Back</a>
          </div>
        </fieldset>

      <?php echo form_close(); ?>

    </div>
     <script type="text/javascript">
      $(".alert").delay(4000).slideUp(200, function() {
          $(this).alert('close');
      });
    </script>