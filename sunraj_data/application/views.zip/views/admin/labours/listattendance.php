    <div class="container top">

      <ul class="breadcrumb">
        <li>
          <a href="<?php echo site_url("admin"); ?>">
            <?php echo ucfirst($this->uri->segment(1));?>
          </a> 
          <span class="divider">/</span>
        </li>
        <li class="active">
          <?php echo "Attendance";?>
        </li>
      </ul>

      <div class="page-header users-header">
        <h2>
          <?php echo "Attendance";?> 
        </h2>
      </div>
      
      <div class="row">
        <div class="span12 columns">
          <div class="well">
           
            <?php
           
            $attributes = array('class' => 'form-inline reset-margin', 'id' => 'myform');
           
            $options_manufacture = array(0 => "all");
            foreach ($manufactures as $row)
            {
              $options_manufacture[$row['userid']] = $row['fullname'];
            }
            //save the columns names in a array that we will use as filter         
            $options_products = array();    
            foreach ($products as $array) {
              foreach ($array as $key => $value) {
                $options_products[$key] = $key;
              }
              break;
            }

            echo form_open('admin/labours/listattendance/'.$this->uri->segment(4), $attributes);
     
			echo form_label('From:', 'from_string');
			echo form_input('from_string', $from_string_selected, 'class="datepicker1"','style="width: 100px;
height: 26px;"');

              echo form_label('To:', 'to_string');
              echo form_input('to_string', $to_string_selected,'class="datepicker1"', 'style="width: 100px;
height: 26px;"');

              echo form_label('Wage per Day:', 'wage');
			  $attributes_wages=array(
												'name'=>'wage',
												//'value'=>'200',
												//'readonly'=>'readonly',
												'style'=>'width: 100px;height: 20px;'
											);
              echo form_input($attributes_wages);
			  echo "<br>";
			  
              //echo form_label('Filter by Superviser:', 'manufacture_id');
              //echo form_dropdown('manufacture_id', $options_manufacture, $manufacture_selected, 'class="span2"');
			echo "<br>";
			 
              echo form_label('Order by:','order',['style'=>'margin:0 11px;']);
              echo form_dropdown('order', $options_products, $order, 'class="span2"');

              $data_submit = array('name' => 'mysubmit', 'class' => 'btn btn-primary', 'value' => 'Go','style'=>'margin: 0 30px;');

              $options_order_type = array('Asc' => 'Asc', 'Desc' => 'Desc');
              echo form_dropdown('order_type', $options_order_type, $order_type_selected, 'class="span1"');
			
              echo form_submit($data_submit);

            echo form_close();
            ?>

          </div>
          <?php if($message = $this -> session -> flashdata('message')){?>
            <div class="col-md-12 pull-right">
                <div class="alert alert-dismissible alert-success">
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                    <?=$message ?>
                </div>
            </div>
        <?php }?> 
          <table class="table table-striped table-bordered table-condensed">
            <thead>
              <tr>
                <th class="header">#</th>
                <th class="yellow header headerSortDown">Date</th>
                <th class="green header">In-Time</th>
                <th class="red header">Out-Time</th>
                <th class="red header">Location</th>
                <th class="red header">Day Status</th>
               
              </tr>
            </thead>
            <tbody>
              <?php
              $half_day=0;
              $full_day=0;
			  $present=0;
              foreach($products as $row)
              {
                echo '<tr>';
                echo '<td>'.$row['attendaceid'].'</td>';
                echo '<td>'.$row['datetime'].'</td>';
                echo '<td>'.$row['intime'].'</td>';
                echo '<td>'.$row['outtime'].'</td>';
                echo '<td>'.$row['location'].'</td>';
				
				$dateDiff=intval((strtotime($row['outtime'])-strtotime($row['intime']))/60);
				$hours = intval($dateDiff/60);
				$min = intval($dateDiff%60);
				$referenceTimestamp = strtotime( $row['datetime'] );
				$fromTimestamp = strtotime($from_string_selected);
				$toTimestamp = strtotime( $to_string_selected );
				
				if(($referenceTimestamp >= $fromTimestamp) && ($referenceTimestamp <= $toTimestamp)){
					$present++;
				}
				if($hours>=4 && $min>0){  
					$full_day++;	
					echo '<td>Full Day</td>';
                }else if($hours>=5 && $min<=0){  
					$full_day++;	
					echo '<td>Full Day</td>';
                }
				else{
					$half_day++;
					echo '<td>Half Day</td>';
                }
                
                echo '</tr>';
               
              }
             // print_r($full_day." ".$half_day);exit;
              ?>      
            </tbody>
          </table>

          <?php echo '<div class="pagination">'.$this->pagination->create_links().'</div>'; 
  
				if(isset($_POST['mysubmit'])){
					$date1=date_create($from_string_selected);
					$date2=date_create($to_string_selected);
					$diff=date_diff($date1,$date2);
					$totalday=$diff->format("%a ");
					//$totalday=$diff->format("%R%a ");
					
		 ?>
				<table class="table  table-bordered table-condensed"> 
				  <thead>
							  <tr>
								<th class="header">Day Status</th>
								<th class="yellow header headerSortDown">Days Count</th>
								<th class="yellow header headerSortDown">Sub-Total</th>
								</tr>
				  </thead>
				  <tbody>
							 <?php
							 
									echo '<tr>';
									echo '<th>Full Days</th>';
									echo '<td>'.$full_day.'</td>';
									echo '<td>'.$full_day*($_POST['wage']).'/-</td>';
									echo '</tr>';
									echo '<tr>';
									echo '<th>Half Days</th>';
									echo '<td>'.$half_day.'</td>';
									echo '<td>'.$half_day*($_POST['wage']/2).'/-</td>';
									echo '</tr>';
									echo '<tr>';
									if($leaveday==1){
										$leave_day=$totalday-$present;
										echo '<th>Leave Days</th>';
										echo '<td>'.$leave_day.'</td>';
										echo '<td>0</td>';
										echo '</tr>';
										echo '<tr>';
									}
									echo '<th colspan="2">Total</th>';
									echo '<td>'.($full_day*($_POST['wage'])+$half_day*($_POST['wage']/2)).' /-</td>';
									echo '</tr>';
								
								
							 ?>
               </tbody>
			</table>
			<?php }?>
      </div>
    </div>