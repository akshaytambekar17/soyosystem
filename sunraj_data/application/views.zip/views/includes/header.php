<!DOCTYPE html> 
<html lang="en-US">
<head>
  <title>CodeIgniter Admin Sample Project</title>
  <meta charset="utf-8">
  <link href="<?php echo base_url(); ?>assets/css/admin/global.css" rel="stylesheet" type="text/css">
	<link href="<?php echo base_url(); ?>assets/css/admin/jquery.datetimepicker.css" rel="stylesheet" type="text/css">
	<script src="<?php echo base_url(); ?>assets/js/jquery-1.7.1.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/admin.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/jquery.datetimepicker.full.js"></script>
</head>
<body>
	<div class="navbar navbar-fixed-top">
	  <div class="navbar-inner">
	    <div class="container">
	      <a class="brand">Project Name</a>
	      <ul class="nav">
	        <li <?php if($this->uri->segment(2) == 'labours'){echo 'class="active"';}?>>
	          <a href="<?php echo base_url(); ?>admin/labours">Labours</a>
	        </li>
	        <li <?php if($this->uri->segment(2) == 'supervisers'){echo 'class="active"';}?>>
	          <a href="<?php echo base_url(); ?>admin/supervisers">Supervisers</a>
	        </li>
	       <li <?php if($this->uri->segment(2) == 'shift'){echo 'class="active"';}?>>
	          <a href="<?php echo base_url(); ?>admin/shift/listshift">Shift Management</a>
	        </li>
					<li <?php if($this->uri->segment(2) == 'notification'){echo 'class="active"';}?>>
	          <a href="<?php echo base_url(); ?>admin/notification/listnotification">Notifications<span class="badge badge-secondary"><sup style="backgroud-color:red;"><?php echo $this->manufacturers_model->count_notification(); ?></sup> </span> <?php echo $this->notifications->display_js(); ?></a>
	        </li>
					 <li class="dropdown">
	          <a href="#" class="dropdown-toggle" data-toggle="dropdown">System <b class="caret"></b></a>
	          <ul class="dropdown-menu">
	            <li>
	              <a href="<?php echo base_url(); ?>admin/logout">Logout</a>
	            </li>
	          </ul>
	        </li>
	      </ul>
	    </div>
	  </div>
	</div>	
